-- 脚本名称
script.set_name("本地玩家死亡")
script.set_desc("使本地玩家死亡")
log.new_key("本地玩家死亡", 0.89, 0.44, 0.11, true)
toast.add_success("脚本加载完成", "本地玩家死亡功能已激活。")

-- 获取本地玩家的ID
local localPlayerIndex = native.player.player_id()

-- 函数：使本地玩家死亡
local function killLocalPlayer()
    local playerPed = native.player.get_player_ped(localPlayerIndex)

    -- 检查角色是否存在
    if playerPed and native.entity.does_entity_exist(playerPed) then
        native.entity.set_entity_health(playerPed, 0) -- 设置健康值为0，使其死亡
        toast.add_success("本地玩家已死亡", "已将本地玩家设为死亡。")
    else
        toast.add_error("操作失败", "本地玩家角色不存在。")
    end
end

-- 在菜单中添加按钮以杀死本地玩家
local menuRoot = menu.script_root() -- 获取脚本菜单根目录
local killOption = menuRoot:add_button("杀死本地玩家", {}, function()
    killLocalPlayer() -- 调用死亡函数
end)

script.keep_alive()

-- 清理时的提示
script.on_shutdown(function()
    toast.add_info("脚本已停止", "本地玩家死亡功能已停止.")
end)

